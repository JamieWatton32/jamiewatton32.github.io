Requirements:
Python:3.12.1+
Selenium: https://pypi.org/project/selenium/ pip install selenium
Numpy: https://pypi.org/project/numpy/ pip install numpy
Pandas: https://pypi.org/project/pandas/ pip install pandas
Beautifulsoup4: https://pypi.org/project/beautifulsoup4/ pip install bs4
lxml: https://pypi.org/project/lxml/ pip install lxml



